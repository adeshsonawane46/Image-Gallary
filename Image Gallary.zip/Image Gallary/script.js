const images = document.querySelectorAll(".gallery img");
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightboxImg");
const caption = document.getElementById("caption");
const closeBtn = document.getElementById("closeBtn");
const nextBtn = document.getElementById("next");
const prevBtn = document.getElementById("prev");

let currentIndex = 0;

images.forEach((img, index) => {
  img.addEventListener("click", () => {
    currentIndex = index;
    openLightbox(index);
  });
});

function openLightbox(index) {
  lightbox.style.display = "flex";
  lightboxImg.src = images[index].src;
  caption.textContent = images[index].alt;
}

function showNext() {
  currentIndex = (currentIndex + 1) % images.length;
  openLightbox(currentIndex);
}

function showPrev() {
  currentIndex = (currentIndex - 1 + images.length) % images.length;
  openLightbox(currentIndex);
}

closeBtn.onclick = () => lightbox.style.display = "none";
nextBtn.onclick = showNext;
prevBtn.onclick = showPrev;

window.onclick = function(event) {
  if (event.target === lightbox) {
    lightbox.style.display = "none";
  }
};
